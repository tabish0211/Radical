﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejalProj
{
    class Program
    {
        //entry point method
        //static void Main(string[] args)
        //{
        //    //Console.WriteLine("Hello world");
        //    //Console.Write("It never changes to new line");
        //    //Console.WriteLine("hi how are you");
        //    ////cw press tabs two times
        //   // Console.WriteLine("hello world "+ "how are you");
        //    //varaible--varaible memory to store specific data 
        //    //int x = 10;
        //    //string s = "Raj";
        //    //Console.WriteLine(s);
        //    //Console.WriteLine(x);

        //   // Details();
        //    string name = GetName();//Default methods--No parameters
        //    int age = GetAge();
        //    Display(name, age);//actual argument
        //   // Console.WriteLine("user name is:" + name + " and Age is :" + age);
        //    Console.ReadLine();
        //}

       static void Details() {
            
            Console.WriteLine("Enter name");
            string name = Console.ReadLine();
            Console.WriteLine("enter age");
            int age = Convert.ToInt32(Console.ReadLine());
           
           
        
        }

       static string GetName()
       {

           Console.WriteLine("Enter name");
           string name = Console.ReadLine();
           return name;          

       }

       static int GetAge()
       {

           Console.WriteLine("Enter age");
           int age = Convert.ToInt32(Console.ReadLine());
           return age;

       }

       static void Display(string name,int age) {
            Console.WriteLine("user name is:" + name + " and Age is :" + age);
       }



    }
}
