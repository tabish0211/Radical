﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejalProj
{
   public  class ArrayDemo
    {

       public void initisedarr() {

           Console.WriteLine("enetr the size of the array");
           int size = Convert.ToInt32(Console.ReadLine());

           int[] arr = new int[size];
           ArrayOneDimensionalDemo(arr);
       
       }
       public void ArrayOneDimensionalDemo(int[] newarr) { 
       
           //iniatialized
         
           //for (int i = 0; i < size; i++)
           for (int i = 0; i < newarr.Length; i++)
           {
               newarr[i] = i + 2;
               Console.WriteLine(newarr[i]);
           }


       }


       public void ArrayTwoDimensionalDemo()
       {
           Console.WriteLine("Enter number of rows");
           int row = Convert.ToInt32(Console.ReadLine());
           Console.WriteLine("Enter number of columns");
           int col = Convert.ToInt32(Console.ReadLine());

           int[,] arr = new int[row, col];

           for (int rowindex = 0; rowindex < row; rowindex++)
           {
               for (int colindex = 0; colindex < col; colindex++)
               {
                   Console.WriteLine(arr[rowindex,colindex]);
               }
           }

       }

       public void ArrayTwoDimensionalDemoWithSize()
       {
           Console.WriteLine("Enter number of rows");
           int row = Convert.ToInt32(Console.ReadLine());
           Console.WriteLine("Enter number of columns");
           int col = Convert.ToInt32(Console.ReadLine());

           int[,] arr = new int[row, col];

           for (int rowindex = 0; rowindex < arr.GetLength(0); rowindex++)
           {
               for (int colindex = 0; colindex < arr.GetLength(1); colindex++)
               {
                   Console.WriteLine(arr[rowindex, colindex]);
               }
           }

       }

       public void ArrayMultiDimensio_JaggedArray()
       {
           int[][] arr = new int[3][];//defined the rows
           arr[0] = new int[3];//1-d array for oth row
           arr[1] = new int[2];
           arr[2] = new int[5];

           for (int i = 0; i < arr.GetLength(0); i++)
           {
               for (int j = 0; j < arr[i].Length; j++)
               {
                   Console.WriteLine(arr[i][j]);
               }
               
           }


       }

       public void ArraySortReverse()
       {
           
           int[] arr={5,2,7,4,8,6};
           //before
           foreach (var item in arr)
           {
               Console.WriteLine(item);
               
           }
           //descending order
           Array.Sort(arr);
           Array.Reverse(arr);
           //after
           foreach (var item in arr)
           {
               Console.WriteLine(item);
           }


       }
    }
}
