﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejalProj
{
   public  class Decisions
    {
       public void IfelseDemo() { 
       
           //find largest in three numbers
           Console.WriteLine("Enter three numbers");
           int num1 = Convert.ToInt32(Console.ReadLine());
           int num2 = Convert.ToInt32(Console.ReadLine());
           int num3 = Convert.ToInt32(Console.ReadLine());

           if (num1>num2)
           {
               if (num1>num3)
               {
                   Console.WriteLine("maximum is {0}",num1);
               }
               else
               {
                   Console.WriteLine("maximum is {0}", num3);
               }
               
           }
           else if (num2>num3)
           {

               Console.WriteLine("maximum is {0}", num2);
           }
           else
           {
               Console.WriteLine("maximum is {0}", num3);
           }
           
       
       }

       public void optimisedMaxThree() {
          
           Console.WriteLine("Enter three numbers");
           int num1 = Convert.ToInt32(Console.ReadLine());
           int num2 = Convert.ToInt32(Console.ReadLine());
           int num3 = Convert.ToInt32(Console.ReadLine());
           //19,17,21
           if (num1 > num2 && num1 > num3)
           {
               Console.WriteLine("maximum is {0}", num1);              

           }
           else if (num2 > num3)
           {

               Console.WriteLine("maximum is {0}", num2);
           }
           else
           {
               Console.WriteLine("maximum is {0}", num3);
           }
           
       }


       public void ConditionalOperator()
       {
           //int res = 1 > 0 ? 1 : 0;
           //string str = 1 > 0 ? "Hi" : "bye";
           //Console.WriteLine(str);
           //string str = (12 > 10 ?(12>13?"Hi":"bye")  : (5>6?"yes 5":"No 5"));
           //Console.WriteLine(str);

           Console.WriteLine("Enter three numbers");
           int num1 = Convert.ToInt32(Console.ReadLine());
           int num2 = Convert.ToInt32(Console.ReadLine());
           int num3 = Convert.ToInt32(Console.ReadLine());
           //19,17,21
           string maxText = (num1 > num2 && num1 > num3 )? "max is " + num1 : ((num2 > num3) ? "max is " + num2 : "max is " + num3);
           Console.WriteLine(maxText);
           //if (num1 > num2 && num1 > num3)
           //{
           //    Console.WriteLine("maximum is {0}", num1);

           //}
           //else if (num2 > num3)
           //{

           //    Console.WriteLine("maximum is {0}", num2);
           //}
           //else
           //{
           //    Console.WriteLine("maximum is {0}", num3);
           //}

       }

       public void SwitchCaseDemo() {

           //Console.WriteLine("Enter choice ");
           //int choice = Convert.ToInt32(Console.ReadLine());

           //switch (choice)
           //{
           //    case 1:
           //        Console.WriteLine("execute 1");
           //        break;//to just exit from curly brace
           //    case 2:
           //        Console.WriteLine("execute 2");
           //        break;
           //    case 3:
           //        Console.WriteLine("execute 3");
           //        break;

           //    default:
           //        Console.WriteLine("If nothing matches i will get printed");
           //        break;
           //}

          // Console.WriteLine("I reached exit point");


           Console.WriteLine("Enter choice ");
           string choiceStr =Console.ReadLine();

           switch (choiceStr.ToLower())
           {
               case "hi":
                   Console.WriteLine("execute hi");
                   break;//to just exit from curly brace
               case "bye":
                   Console.WriteLine("execute 2");
                   break;
               case "why":
                   Console.WriteLine("execute 3");
                   break;

               default:
                   Console.WriteLine("If nothing matches i will get printed");
                   break;
           }
       
       }
    }
}
