﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejalProj
{
    class loopsandarray
    {
        static void Main(string[] args)
        {
           //decision
           // Decisions obj = new Decisions();
           // obj.IfelseDemo();
            //obj.ConditionalOperator();
           // obj.SwitchCaseDemo();

            //Loopings
           // Loopings objloop = new Loopings();
           // objloop.ForDemo();
            //objloop.WhileDemo();

            ArrayDemo objarr = new ArrayDemo();
            //objarr.initisedarr();
           // objarr.ArrayTwoDimensionalDemo();
            //objarr.ArrayTwoDimensionalDemoWithSize();
          //  objarr.ArrayMultiDimensio_JaggedArray();
           // objarr.ArraySortReverse();
            Keywrods objkeywprd = new Keywrods();
            objkeywprd.NullableDemo();
            Console.ReadLine();
        }
    }
}
