﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejalProj
{
    public class Loopings
    {

        public void ForDemo() {

            //Console.WriteLine("Enter Number");
            //int num = Convert.ToInt32(Console.ReadLine());

            //for (int i = 1; i <= 10; i++)
            //{
            //    Console.WriteLine(num + "x" + i + "={0}", num * i);
            //    //Console.WriteLine(num*i);
            //}\

            //you want to come out of loop
            //for (int i = 0; i < 11; i++)
            //{
            //    if (i==6)
            //    {
            //        break;
            //    }
            //    Console.WriteLine(i);
            //}

            //Skip the sequence--continue
            for (int i = 1; i < 11; i++)
            {
                if (i == 6)
                {
                    continue;
                }
                Console.WriteLine(i);
            }



        
        }

        public void WhileDemo()
        {
            //Console.WriteLine("Enter Number");
            //int num = Convert.ToInt32(Console.ReadLine());
            //int i = 1;
            //do
            //{
            //    Console.WriteLine(num*i);
            //    i++;
            //} while (i<11);

            //int j = 1;
            //while (j<11)
            //{
            //    Console.WriteLine(num*j);
            //    j++;
            //}
            //Console.WriteLine("exit");

            //string choice = "y";
            //while (choice.ToLower().Equals("y"))
            //{
            //    Console.WriteLine("Yes");
            //    Console.WriteLine("enter choice");
            //    choice = Console.ReadLine();
            //}

            //Console.WriteLine("out of loop");

            //foreach
        }
    }
}
