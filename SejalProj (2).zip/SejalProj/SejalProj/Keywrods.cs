﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejalProj
{
    public class Keywrods
    {
        //ref--pass the address of the variable--saving memory

        public void Method1() {
            int x = 1, y = 3;
            Method2(ref x,ref y);
        }

        public void Method2(ref int x,ref int y)
        {
            Console.WriteLine("{0}{1}",x,y);
        }

        //out--

        public void Method3() {

            int x, y, sum;
            x = 1; y = 2;
            Method4(x, y,out sum);
            Console.WriteLine(sum);
        
        }

        public void Method4(int x,int y,out int sum)
        {

            sum=x + y;
        }


        public void NullableDemo()
        {

            string str = null;//reference type 
            int? x = null;//primitive types
            Console.WriteLine(x);

        }
    }
}
