﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeniferConsoleApplication
{
    public class ArrayDemos
    {
        static void Main()
        {

            ArrayDemos obj = new ArrayDemos();
            obj.OneDimensionalArrayDemo();
           // obj.TwoDArrayDemo();
            Console.ReadLine();
           
        
        }

        public void OneDimensionalArrayDemo() {

            Console.WriteLine("Enter the number of students to whom you want tptake the roll numbers");
            int size = Convert.ToInt32(Console.ReadLine());

            int[] rollNumbers = new int[size];

            Console.WriteLine("Enter Roll No:");
            //i/p
            for (int i = 0; i < rollNumbers.Length; i++)
            {
                rollNumbers[i] = Convert.ToInt32(Console.ReadLine());

            }

            //o/p
            //for (int i = 0; i < rollNumbers.Length; i++)
            //{
            //    Console.WriteLine(rollNumbers[i]);

            //}

            foreach (var item in rollNumbers)
            {
                Console.WriteLine(item);
            }
           
        
        }

        public void TwoDArrayDemo() 
        {

            Console.WriteLine("Enter no of rows");
            int row=Convert.ToInt32(Console.ReadLine());
                
            Console.WriteLine("Enter no of columns");
            int col = Convert.ToInt32(Console.ReadLine());

            int[,] arr_2d = new int[row, col];

            Console.WriteLine("Enter Roll numbers");
           
            
            //for (int i = 0; i < row; i++)
            for (int i = 0; i < arr_2d.GetLength(0); i++)
            {
                //for (int j = 0; j < col; j++)
                for (int j = 0; j < arr_2d.GetLength(1); j++)
                {
                    arr_2d[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            //o/p

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    Console.WriteLine(arr_2d[i, j]);
                }
            }

        
        }


    }
}
