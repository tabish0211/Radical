﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeniferConsoleApplication
{
    public class Loopings
    {
        //static void Main() 
        //{
        //    Loopings obj = new Loopings();
        //    //obj.DemoForLoop();
        //   // obj.DemoForLoopTable();
        //    //obj.DemoWhileLoop();
        //    obj.DemoDoWhileLoop();
        //    Console.ReadLine();
        
        //}

        //for loop demo
        public void DemoForLoop() {

            for (int i = 1; i < 10; i++)
            {
                Console.WriteLine(i);
            }

        
        }

        

        public void DemoForLoopTable()
        {
            Console.WriteLine("Enter the number");
            int num = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <=10; i++)
            {
                Console.WriteLine(i*num);
            }

        }

        public void DemoWhileLoop()
        {
            int i = 1;
            while (i <= 10)
            {
                Console.WriteLine(i);
                i++;
            }

        }

        public void DemoDoWhileLoop()
        {
            int i = 1;
            do
            {
                Console.WriteLine(i);
                i++;
            } while (i<=10);

        }


    }
}
