﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SandhyaMVC.Controllers
{
    public class ActionSelectrorController : Controller
    {
        //

        [ActionName("find")]
        
        public ActionResult Index()
        {
            return View();
        }
	}
}