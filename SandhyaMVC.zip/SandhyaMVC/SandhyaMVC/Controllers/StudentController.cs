﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SandhyaMVC.Models;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SandhyaMVC.Controllers
{
    public class StudentController : Controller
    {
        //
        // GET: /Student/
        public ActionResult Index()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString());
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from student", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            List<Student> lstStudents = new List<Student>();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Student obj = new Student()
                    {
                        RollNo = Convert.ToInt32(dr["rollno"].ToString()),
                        Name = dr["name"].ToString(),
                        Age = Convert.ToInt32(dr["age"].ToString())
                    };

                    lstStudents.Add(obj);

                }

            }

            dr.Close();
            con.Close();

            // ViewData["students"] = lstStudents;
            ViewBag.students = lstStudents;
            // TempData["students"] = lstStudents;
            //Session["students"] = lstStudents;
            return View();
        }


        public ActionResult EditCall(int rollNo)
        {
            // Student obj = DBRecord(rollNo);

            return View();
        }


        public ActionResult DetaislCall(Student obj)
        {

            return View();
        }

        public ActionResult DeletelCall(Student obj)
        {

            return View();
        }



    }
}