﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SandhyaMVC.Controllers
{
    public class CustomerController : Controller
    {
        //
        // GET: /Customer/
        public ViewResult Home()
        {
            return View();
        }

        public ActionResult content()
        {
            int sum = 1 + 2;
            return Content(sum.ToString());
        }

        public ActionResult jsonRecord()
        {
            var cust = new
            {
                Id=101,
                Name="Raj"
            };

            return Json(cust, JsonRequestBehavior.AllowGet);
        }

        public ActionResult RetrunPartial()
        {
            return PartialView("_myPartial");
        }

        public RedirectResult RedirectDemo()
        {
            return Redirect("RetrunPartial");
        }

        public ActionResult RedirecToActionDemo()
        {
            return RedirectToAction("About", "Home");
        }  
	}


    }